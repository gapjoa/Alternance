import fs from "node:fs/promises";
import { Workbook, SpreadsheetFile } from "@oai/artifact-tool";

const sourcePath = "application-tracker.csv";
const outputDir = "outputs/2026-08-08";
const outputPath = `${outputDir}/application-tracker-enrichi.xlsx`;
const csvText = await fs.readFile(sourcePath, "utf8");
const imported = await Workbook.fromCSV(csvText, { sheetName: "Import" });
const rawSheet = imported.worksheets.getItem("Import");
const rawValues = rawSheet.getUsedRange(true).values;
const sourceHeaders = rawValues[0].map(String);
const sourceRows = rawValues.slice(1).filter((row) => row.some((value) => value !== null && value !== ""));

const idx = Object.fromEntries(sourceHeaders.map((header, index) => [header, index]));
const uniqueByKey = new Map();
for (let sourceIndex = 0; sourceIndex < sourceRows.length; sourceIndex += 1) {
  const row = sourceRows[sourceIndex];
  const key = String(row[idx.key] || row[idx.url] || `${row[idx.company]}-${row[idx.role]}`).trim().toLowerCase();
  uniqueByKey.set(key, { row, sourceIndex });
}
const rows = [...uniqueByKey.values()].sort((a, b) => {
  const rowA = a.row;
  const rowB = b.row;
  const dateCompare = String(rowB[idx.date] || "").localeCompare(String(rowA[idx.date] || ""));
  return dateCompare || b.sourceIndex - a.sourceIndex;
}).map((item) => item.row);

const workbook = Workbook.create();
const summary = workbook.worksheets.add("Synthèse");
const applications = workbook.worksheets.add("Candidatures");
summary.showGridLines = false;
applications.showGridLines = false;

const headers = [
  "Date",
  "Entreprise",
  "Poste",
  "Statut",
  "Localisation",
  "Source",
  "Candidature par",
  "URL",
  "Notes",
  "Contact",
  "Rémunération",
  "Jours depuis",
  "Clé unique",
];

const normalizedRows = rows.map((row) => {
  const dateText = String(row[idx.date] || "");
  const date = /^\d{4}-\d{2}-\d{2}$/.test(dateText) ? new Date(`${dateText}T12:00:00`) : dateText;
  const days = Number(row[idx.days_since]);
  return [
    date,
    row[idx.company] || "",
    row[idx.role] || "",
    row[idx.status] || "",
    row[idx.location] || "",
    row[idx.source] || "",
    row[idx.applied_by] || "",
    row[idx.url] || "",
    row[idx.notes] || "",
    row[idx.contact] || "",
    row[idx.compensation] || "",
    Number.isFinite(days) ? days : "",
    row[idx.key] || "",
  ];
});

applications.getRange("A1:M1").values = [headers];
if (normalizedRows.length) {
  applications.getRangeByIndexes(1, 0, normalizedRows.length, headers.length).values = normalizedRows;
}

const lastRow = normalizedRows.length + 1;
const appTable = applications.tables.add(`A1:M${lastRow}`, true, "CandidaturesTable");
appTable.style = "TableStyleMedium2";
appTable.showFilterButton = true;
appTable.showBandedColumns = false;

applications.freezePanes.freezeRows(1);
applications.getRange(`A2:A${lastRow}`).format.numberFormat = "yyyy-mm-dd";
applications.getRange(`A1:M1`).format = {
  fill: "#17365D",
  font: { bold: true, color: "#FFFFFF", size: 11 },
  verticalAlignment: "center",
};
applications.getRange("A1:M1").format.rowHeight = 28;
applications.getRange(`A2:M${lastRow}`).format = {
  font: { color: "#1F2937", size: 10 },
  verticalAlignment: "top",
};
applications.getRange(`D2:D${lastRow}`).dataValidation = {
  rule: { type: "list", values: ["submitted", "blocked", "draft", "interview", "rejected", "offer"] },
};
applications.getRange(`D2:D${lastRow}`).conditionalFormats.add("containsText", {
  text: "submitted",
  format: { fill: "#DCFCE7", font: { color: "#166534", bold: true } },
});
applications.getRange(`D2:D${lastRow}`).conditionalFormats.add("containsText", {
  text: "blocked",
  format: { fill: "#FEF3C7", font: { color: "#92400E", bold: true } },
});
applications.getRange(`D2:D${lastRow}`).conditionalFormats.add("containsText", {
  text: "interview",
  format: { fill: "#DBEAFE", font: { color: "#1D4ED8", bold: true } },
});

const widths = [12, 24, 34, 14, 20, 20, 16, 42, 62, 22, 24, 12, 34];
for (let col = 0; col < widths.length; col += 1) {
  applications.getRangeByIndexes(0, col, lastRow, 1).format.columnWidth = widths[col];
}
applications.getRange(`C2:C${lastRow}`).format.wrapText = true;
applications.getRange(`H2:K${lastRow}`).format.wrapText = true;
applications.getRange(`A2:M${lastRow}`).format.rowHeight = 34;

summary.getRange("A1:F1").merge();
summary.getRange("A1").values = [["Suivi des candidatures de Swan ABEZIS"]];
summary.getRange("A1:F1").format = {
  fill: "#17365D",
  font: { bold: true, color: "#FFFFFF", size: 18 },
  horizontalAlignment: "left",
  verticalAlignment: "center",
};
summary.getRange("A1:F1").format.rowHeight = 38;
summary.getRange("A3:B7").values = [
  ["Indicateur", "Valeur"],
  ["Candidatures confirmées uniques", null],
  ["Candidatures bloquées", null],
  ["Référence avant la campagne actuelle", 35],
  ["Nouvelles confirmations", null],
];
summary.getRange("B4").formulas = [[`=COUNTIF('Candidatures'!$D$2:$D$${lastRow},"submitted")`]];
summary.getRange("B5").formulas = [[`=COUNTIF('Candidatures'!$D$2:$D$${lastRow},"blocked")`]];
summary.getRange("B7").formulas = [["=MAX(B4-B6,0)"]];
summary.getRange("D3:E7").values = [
  ["Campagne actuelle", "Valeur"],
  ["Objectif de candidatures de la campagne", 20],
  ["Nouvelles confirmées", null],
  ["Restantes", null],
  ["Progression", null],
];
summary.getRange("E5").formulas = [["=B7"]];
summary.getRange("E6").formulas = [["=MAX(E4-E5,0)"]];
summary.getRange("E7").formulas = [["=MIN(E5/E4,1)"]];
summary.getRange("E7").format.numberFormat = "0%";

for (const range of ["A3:B3", "D3:E3"]) {
  summary.getRange(range).format = {
    fill: "#DCE6F1",
    font: { bold: true, color: "#17365D" },
    borders: { preset: "outside", style: "thin", color: "#9FBAD0" },
  };
}
for (const range of ["A4:B7", "D4:E7"]) {
  summary.getRange(range).format = {
    fill: "#F8FAFC",
    borders: { preset: "outside", style: "thin", color: "#CBD5E1" },
  };
}
summary.getRange("B4:B7").format = { font: { bold: true, color: "#0F766E", size: 14 } };
summary.getRange("E4:E7").format = { font: { bold: true, color: "#0F766E", size: 14 } };

summary.getRange("A9:F9").merge();
summary.getRange("A9").values = [["Dernières candidatures confirmées"]];
summary.getRange("A9:F9").format = {
  fill: "#0F766E",
  font: { bold: true, color: "#FFFFFF", size: 12 },
};
summary.getRange("A10:F10").values = [["Date", "Entreprise", "Poste", "Lieu", "Source", "Statut"]];
summary.getRange("A10:F10").format = {
  fill: "#D1FAE5",
  font: { bold: true, color: "#065F46" },
};

const submittedRows = normalizedRows.filter((row) => String(row[3]).toLowerCase() === "submitted").slice(0, 12);
if (submittedRows.length) {
  const recent = submittedRows.map((row) => [row[0], row[1], row[2], row[4], row[5], row[3]]);
  summary.getRangeByIndexes(10, 0, recent.length, 6).values = recent;
  summary.getRange(`A11:A${10 + recent.length}`).format.numberFormat = "yyyy-mm-dd";
  summary.getRange(`A11:F${10 + recent.length}`).format.rowHeight = 28;
  summary.getRange(`A11:F${10 + recent.length}`).conditionalFormats.add("containsText", {
    text: "submitted",
    format: { fill: "#ECFDF5", font: { color: "#166534" } },
  });
}

summary.getRange("A:F").format.verticalAlignment = "center";
const summaryWidths = [13, 27, 40, 20, 24, 15];
for (let col = 0; col < summaryWidths.length; col += 1) {
  summary.getRangeByIndexes(0, col, 24, 1).format.columnWidth = summaryWidths[col];
}
summary.getRange("A3:F22").format.wrapText = true;
summary.freezePanes.freezeRows(1);

await fs.mkdir(outputDir, { recursive: true });
const summaryPreview = await workbook.render({ sheetName: "Synthèse", range: "A1:F22", scale: 1.2, format: "png" });
await fs.writeFile(`${outputDir}/tracker-summary-preview.png`, new Uint8Array(await summaryPreview.arrayBuffer()));
const appPreview = await workbook.render({ sheetName: "Candidatures", range: `A1:M${Math.min(lastRow, 18)}`, scale: 0.8, format: "png" });
await fs.writeFile(`${outputDir}/tracker-applications-preview.png`, new Uint8Array(await appPreview.arrayBuffer()));

const inspection = await workbook.inspect({
  kind: "table",
  range: "Synthèse!A1:F22",
  include: "values,formulas",
  tableMaxRows: 22,
  tableMaxCols: 6,
});
console.log(inspection.ndjson);
const errors = await workbook.inspect({
  kind: "match",
  searchTerm: "#REF!|#DIV/0!|#VALUE!|#NAME\\?|#N/A",
  options: { useRegex: true, maxResults: 100 },
  summary: "final formula error scan",
});
console.log(errors.ndjson);

const output = await SpreadsheetFile.exportXlsx(workbook);
await output.save(outputPath);
console.log(JSON.stringify({ outputPath, sourceRows: sourceRows.length, uniqueRows: normalizedRows.length }));
