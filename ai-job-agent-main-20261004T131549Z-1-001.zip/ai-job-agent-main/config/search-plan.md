# Plan de recherche d'alternance — Swan ABEZIS

Statut : **actif et urgent** · Dernière mise à jour : `2026-08-10` · Version : 2

## Ce que je recherche

Je recherche une alternance à partir de septembre 2026, dans le cadre de mon Master Digital Transformation & Innovation IA à l'EM Normandie. Ma cible prioritaire est un poste de Business Developer, BDR, SDR, Sales ou Growth Sales orienté B2B, idéalement dans une entreprise technologique liée à l'IA, la data, le cloud, la cybersécurité, la fintech, la RegTech ou l'identité numérique.

Je veux rejoindre une équipe dans laquelle je pourrai contribuer à la génération de pipeline commercial, à la prospection et à la qualification de comptes, aux partenariats, aux réponses à appels d'offres et à l'automatisation des activités marketing ou commerciales. Mon avantage différenciant est de pouvoir parler à la fois business, automatisation et conformité financière.

## Postes cibles

### Priorité 1 — candidater dès que les critères sont compatibles

- Business Developer B2B en alternance
- Business Development Representative / BDR en alternance
- Sales Development Representative / SDR en alternance
- Growth Business Developer en alternance
- Chargé de développement commercial B2B en alternance

### Priorité 2 — candidater si les missions restent fortement B2B et commerciales

- Partnerships / Partner Development en alternance
- Revenue Operations / Sales Operations junior en alternance
- Go-to-Market / Sales Enablement en alternance
- Account Executive junior en alternance
- Ingénieur d'affaires / Chargé d'affaires B2B en alternance

### Secteurs prioritaires

1. Fintech et services financiers B2B
2. Paiements et infrastructures de paiement
3. Banque, assurance et logiciels destinés aux acteurs financiers
4. RegTech, KYC/AML et conformité
5. Identité numérique, authentification et cybersécurité B2B
6. Crypto/Web3 uniquement lorsque l'activité est réglementée et orientée entreprise
7. SaaS B2B avec une forte composante IA ou automatisation

## Ce que l'alternance doit permettre

- Travailler sur de vrais cycles de vente ou de partenariat B2B.
- Générer, qualifier et suivre des leads ou comptes cibles.
- Utiliser un CRM et mesurer les résultats par des KPI concrets.
- Participer aux propositions commerciales, appels d'offres, démonstrations ou rendez-vous clients.
- Construire ou améliorer des automatisations de prospection et d'activité commerciale.
- Capitaliser sur l'expérience fintech, identité numérique et conformité de Swan.
- Être encadré par une équipe commerciale, growth, partenariats ou go-to-market identifiable.

## Filtres obligatoires avant candidature

- Contrat explicitement proposé en alternance, apprentissage ou professionnalisation.
- Niveau Master 1 / Bac+4 accepté pour la rentrée 2026.
- Début entre fin septembre 2026 et début octobre 2026.
- Contrat de deux ans compatible avec le rythme de trois semaines en entreprise et une semaine à l'école.
- Localisation : Paris, La Défense et plus largement l'Île-de-France. Toute autre zone doit être validée avant candidature.
- Candidat français, autorisé à travailler en France sans restriction.
- Rémunération minimale souhaitée : 1 400 EUR par mois ; brut ou net à confirmer avant de renseigner une prétention chiffrée dans un formulaire.
- Missions comportant une composante B2B réelle et non uniquement du community management ou de la communication.
- Exclure les postes principalement marketing, communication, contenu, acquisition B2C ou événementiel.
- Exclure les postes de Customer Success, Customer Care et support client, même lorsqu'ils comportent une petite composante commerciale.
- Exclure les postes exigeant un anglais courant, fluent ou bilingue. Accepter l'anglais opérationnel ou B2 lorsque le français reste la langue de travail principale.
- Offre publiée récemment et toujours active.

## Offres à écarter ou déprioriser

- Stage, CDI, freelance ou service civique présenté à la place d'une alternance.
- Vente B2C en boutique, porte-à-porte ou centre d'appels.
- Rémunération exclusivement à la commission.
- Poste principalement marketing, communication, création de contenu ou community management, même si l'intitulé contient le mot growth.
- Poste principalement Customer Success, Customer Care, support ou fidélisation client.
- Poste principalement consacré à la saisie ou à l'annotation de données.
- Offre demandant un niveau technique, juridique ou de closing senior non démontré par le CV.
- Annonce ancienne, dupliquée, sans entreprise identifiable ou sans missions précises.

## Règle de sélection pour l'agent

Une offre ne doit être proposée dans le groupe « candidater maintenant » que si elle respecte tous les filtres obligatoires et obtient au moins 4,0/5 après évaluation. La priorité va aux annonces publiées depuis moins de sept jours, avec une préférence pour celles de moins de 72 heures.

Pour chaque offre retenue, l'agent doit expliquer :

1. pourquoi les missions correspondent au profil ;
2. quelles expériences du CV prouvent la compatibilité ;
3. quelles compétences manquent réellement ;
4. quelle version de CV utiliser ou adapter ;
5. quel recruteur, manager ou collaborateur contacter après la candidature.

## Stratégie d'exécution

- Candidater le jour même aux offres fortes publiées depuis moins de 72 heures.
- Adapter le CV sans inventer de résultats ou de compétences.
- Envoyer un message personnalisé au recruteur ou au manager dans les 24 heures suivant la candidature.
- Première relance à J+4 ou J+5 si aucune réponse.
- Dernière relance à J+10.
- Analyser chaque semaine les taux de réponse par intitulé, secteur, source et type de contact.

## Objectif temporel

- Début souhaité : fin septembre 2026 ou début octobre 2026.
- Objectif : obtenir et signer une alternance le plus tôt possible avant la rentrée.
- Priorité immédiate : offres fraîches, candidatures personnalisées et contact direct avec les équipes concernées.

## Préférences entreprises

- Priorité forte aux grands groupes, banques, assureurs, acteurs des paiements et grandes entreprises technologiques.
- Conserver aussi les fintechs, RegTechs et SaaS B2B lorsque l'adéquation est excellente.
- Aucune entreprise formellement exclue à ce stade.

## Informations restant à confirmer

- La rémunération minimale de 1 400 EUR par mois est-elle exprimée en brut ou en net ?
- Politique souhaitée concernant le télétravail.
- Éventuelles entreprises à exclure après examen de la première liste.

## Journal

- `2026-08-07` : plan initial créé à partir des deux CV fournis par Swan ABEZIS.
- `2026-08-07` : rythme 3 semaines/1 semaine, contrat de 2 ans, disponibilité fin septembre-début octobre, mobilité Paris/La Défense/Île-de-France, nationalité française et préférence grands groupes ajoutés.
- `2026-08-07` : première recherche d'offres actives effectuée ; liste de décision ci-dessous, en attente des réponses oui/non de Swan.
- `2026-08-10` : ciblage resserré sur Business Development, BDR, SDR, Sales, Growth Sales, Account Executive et ingénierie d'affaires. Marketing et Customer Success exclus. Anglais courant ou bilingue exclu.

## Première liste de décision — en attente de validation

Recherche effectuée le 2026-08-07. Aucun envoi autorisé avant validation explicite de Swan.

1. **AXA** — Key Account Manager Nouvelle Économie, Nanterre, 12 à 24 mois, rythme en semaines complètes, candidature avant le 18 août 2026. Recommandation : priorité maximale.
   - https://recrutement.axa.fr/nos-offres-emploi/AXAFR_2026020361_2-key-account-manager-nouvelle-economie-f-h-en-alternance
2. **BNP Paribas** — trois pistes actives : Chef de projet Animation Commerciale, Chargé d'actions commerciales et Chargé d'Affaires Entrepreneurs. Recommandation : priorité forte.
   - https://group.bnpparibas/emploi-carriere/offre-emploi/alternance-chef-de-projet-animation-commerciale-h-f
   - https://group.bnpparibas/emploi-carriere/offre-emploi/alternance-charge-d-actions-commerciales-h-f
   - https://group.bnpparibas/emploi-carriere/offre-emploi/alternance-charge-d-affaires-entrepreneurs-h-f
3. **Société Générale** — Business Analyst, pilotage de la performance commerciale ; et Chargé d'Affaires Grandes Entreprises. Recommandation : oui sous réserve de compatibilité de date et de spécialisation.
   - https://careers.societegenerale.com/offres-d-emploi/business-analyst-26000B1I-fr
   - https://careers.societegenerale.com/offres-d-emploi/altcharge-daffaires-grandes-entreprises-260004SS-fr
4. **Student Pop** — Business Developer Junior, Paris, 12 à 24 mois, rythme 3 semaines/1 semaine accepté, 1 400 à 1 700 EUR brut. Recommandation : priorité maximale.
   - https://www.welcometothejungle.com/fr/companies/student-pop/jobs/business-developer-junior-alternance-4j-1j_paris
5. **Bankin'** — Growth Marketing, Paris, 12 à 24 mois, fintech. Recommandation : priorité forte, sous réserve d'accepter un démarrage décalé.
   - https://www.welcometothejungle.com/fr/companies/bankin/jobs/alternance-growth-marketing-paris-h-f-x_paris_BANKI_aKpP4Mr
6. **Lemonway** — Banking Relationship Officer, Paris, paiements/fintech. Recommandation : priorité forte, durée à vérifier.
   - https://careers.speedinvest.com/companies/lemon-way-2/jobs/74811549-banking-relationship-officer-apprenticeship
7. **Praxedo** — Business Developer/BDR SaaS, Paris, 12 à 24 mois, annonce fraîche. Recommandation : priorité forte.
   - https://www.welcometothejungle.com/fr/companies/praxedo/jobs/business-developer-alternance_paris
8. **JOIN** — Business Developer SaaS, Paris, 12 à 24 mois, annonce fraîche. Recommandation : priorité forte.
   - https://www.welcometothejungle.com/fr/companies/join-stories/jobs/business-developer-alternance_paris
9. **triPica** — Growth/Lead Generation B2B, Paris, 12 à 24 mois, salaire annoncé supérieur ou égal à 1 500 EUR. Recommandation : conditionnelle, car la fiche contient des mentions contradictoires de stage.
   - https://www.welcometothejungle.com/fr/companies/tripica/jobs/marketing-growth-hacker-alternance-paris-h-f_paris
10. **Kaplan / Alpadia** — Business Developer partenariats B2I, Paris, 12 à 24 mois. Recommandation : bonne piste hors fintech.
    - https://jobs.smartrecruiters.com/AlpadiaLanguageSchoolsSA/744000114921308-alternance-business-developer-b2i-h-f-
11. **John Paul / Accor** — Chef de projet Loyalty & Insights, Paris, 24 mois, rythme 3 semaines/1 semaine accepté. Recommandation : bonne piste grand groupe, davantage marketing/CRM que business development.
    - https://jobs.smartrecruiters.com/accorcorpo/744000117929380
12. **Viparis** — Attaché commercial/Business Development, Paris, 24 mois. Recommandation : bonne piste grand groupe, hors fintech.
    - https://www.welcometothejungle.com/fr/companies/viparis/jobs/alternant-business-developer-h-f_paris
13. **WE DO GOOD** — Bras droit Ops/Product/Data, Paris, fintech, démarrage septembre/octobre. Recommandation : conditionnelle, missions moins commerciales.
    - https://jobs.makesense.org/en/jobs/we-do-good-alternance-bras-droit-ops-product-data-septembre-2026-x6WFV11jDJxgXqk5I4LM
14. **Swan** — Account Manager Apprentice, Paris, embedded banking. Recommandation : excellente entreprise cible mais date affichée incohérente ; vérifier avant candidature.
    - https://www.welcometothejungle.com/en/companies/swan/jobs/account-manager-apprentice_paris
15. **Keewe** — Growth Acquisition, Paris, fintech B2B. Recommandation : intéressante, mais durée et fraîcheur à vérifier.
    - https://rhalternance.com/jobs/finance-banque-et-assurance/paris/growth-assistant-alternance-stage-keewe-h-f-619626389

### Trouvées mais incompatibles avec l'exigence de deux ans

- **Innovorder** — excellent métier et rythme exact, mais contrat annoncé de 12 mois.
- **Payplug** — Revenue Operations & Strategy très cohérent avec le profil, mais contrat annoncé de 12 mois.
- **PayFit** — aucune alternance Business/Growth compatible actuellement ; les offres visibles sont hors cible ou d'un an.
- **Talan** — Business Developer actif, mais ciblé M2 alors que Swan entre en M1.
- **Wojo** — Business Developer actif, mais contrat de 12 mois.
