# Profil candidat — Swan ABEZIS

Dernière mise à jour : 2026-08-10

## Identité et coordonnées

- Nom : Swan ABEZIS
- Localisation actuelle : Paris, France
- Téléphone : +33 6 78 91 69 81
- Email : swan.abezis@proton.me
- LinkedIn : https://linkedin.com/in/swan-abezis
- Nationalité : française
- Autorisation de travail en France : oui, sans restriction
- Mobilité : Paris et Île-de-France, notamment Paris et La Défense

## Formation

- Master Digital Transformation & Innovation IA, EM Normandie, 2026-2028
- Bachelor Tech & Business, Ynov Paris, 2023-2026
- Niveau recherché à la rentrée 2026 : Master 1 / Bac+4
- Type de contrat recherché : alternance de deux ans
- Rythme école/entreprise : trois semaines en entreprise, une semaine à l'école
- Disponibilité : fin septembre 2026 ou début octobre 2026

## Positionnement professionnel

Swan possède trois années d'expérience chez ShareID, une entreprise B2B spécialisée dans la vérification d'identité numérique pour le secteur financier. Il y a évolué de l'annotation de données IA vers le marketing, puis vers le business development. Son positionnement recherché combine développement commercial B2B, Sales, Growth Sales, automatisation, IA, fintech et conformité réglementaire.

## Expériences et preuves mobilisables

### ShareID — Business Development & IA Marketing, 2025-2026

- Conception et déploiement d'un pipeline automatisé d'audit SEO en sept phases avec Make.com et l'API Claude.
- Construction d'un système automatisé de production de contenus LinkedIn en français et en anglais, avec un rythme de deux à trois publications par semaine.
- Représentation de ShareID au FIC et à VivaTech 2026 sur le stand Orange.
- Production de supports de réponse à des appels d'offres bancaires et fintechs avec la CEO.
- Rédaction et vérification de contenus réglementaires sur KYC/AML, eIDAS 2.0, MiCA/CASP, DORA, DSP2 et EUDI Wallet.
- Suivi des KPI d'acquisition et optimisation de parcours de vérification d'identité côté conversion.

### ShareID — Opérateur puis annotateur de données IA, 2023-2025

- Préparation et annotation de données d'entraînement pour des modèles de détection biométrique.
- Traitement de demandes de vérification d'identité pour des clients du secteur financier.
- Évolution interne sur trois fonctions en trois ans.

### Inovad — Chef de projet junior, secteur du luxe, 2024-2025

- Gestion de huit comptes Instagram et exploration de plus de dix marchés internationaux.
- Réalisation d'une douzaine d'audits web avec recommandations clients.

### Projets

- Accompagnement de deux startups dans leur préparation à la levée de fonds : pitch decks FR/EN, benchmarks de Series A et mapping d'investisseurs.
- MindCare : cadrage produit, tests utilisateurs, business plan et soutenance investisseur pour une PWA de bien-être mental.

## Compétences

- Business : génération de leads B2B, prospection, appels d'offres, Growth Sales, KPI, reporting, supports commerciaux et investisseurs.
- Automatisation : Make.com, API Claude, automatisation marketing et éditoriale.
- Outils : HubSpot, Apollo, Figma, Webflow, Pack Office.
- Secteurs et réglementation : fintech, banque, paiements, identité numérique, KYC/AML, eIDAS 2.0, MiCA/CASP, DORA, DSP2, EUDI Wallet.
- Langues : français natif, anglais B2 déclaré sur la version DOCX et B1/B2 sur la version PDF, chinois A1.

## CV disponibles

- Version PDF courte et visuelle, à privilégier pour les prises de contact humaines : `/Users/swanabezis/Downloads/Swan_ABEZIS_CV.pdf`
- Version DOCX détaillée, à utiliser comme source de contenu mais pas à envoyer en l'état : `/Users/swanabezis/Downloads/CV_Swan_ABEZIS_.docx`
- Base textuelle destinée aux adaptations par annonce : `/Users/swanabezis/Downloads/ai-job-agent-main/cv.md`

## Règles de candidature

- Ne jamais inventer de chiffres pour les leads générés ou les appels d'offres : les marqueurs `[X]` du DOCX doivent être supprimés ou remplacés uniquement après confirmation.
- Ne jamais présenter le niveau d'anglais comme C1 ou bilingue.
- Ne pas transformer une expérience marketing ou projet en responsabilité commerciale non démontrée.
- Ne retenir que les contrats de deux ans compatibles avec un rythme de trois semaines en entreprise et une semaine à l'école.
- Répondre que Swan est français et autorisé à travailler en France sans restriction lorsque la question est posée.
- Prioriser Paris, La Défense et l'Île-de-France.
- Rémunération minimale souhaitée : 1 400 EUR par mois. Ne jamais mentionner cette préférence dans les lettres, messages ou champs facultatifs. Si un formulaire impose une prétention, répondre selon la grille légale et conventionnelle applicable à l'alternance.
- Ne pas candidater aux postes principalement marketing ou communication.
- Ne pas candidater aux postes de Customer Success, Customer Care ou support client.
- La cible est Business Development, BDR, SDR, Sales, Growth Sales, Account Executive, ingénierie d'affaires ou développement commercial B2B.
- Ne pas candidater lorsque l'annonce exige un anglais courant, fluent, bilingue ou la capacité de conduire une vente en anglais. Un anglais opérationnel ou un niveau B2 est acceptable lorsque le français reste la langue principale du poste.
- Adapter le CV aux mots-clés de l'annonce uniquement lorsque l'expérience sous-jacente est réelle.
- Utiliser `swan.abezis@proton.me` comme adresse de contact sur toutes les candidatures.
- Utiliser `06 78 91 69 81` dans les formulaires français et `+33 6 78 91 69 81` lorsque le préfixe international est demandé.
- Joindre par défaut `/Users/swanabezis/Downloads/Swan_ABEZIS_CV.pdf` aux candidatures validées.
- Ne jamais joindre le DOCX actuel, qui contient encore des champs incomplets.
- Ne jamais utiliser le caractère tiret cadratin Unicode U+2014 dans les réponses libres, lettres, emails et messages rédigés pour Swan.
- Après validation explicite d'une entreprise ou d'une offre par Swan, remplir automatiquement les champs factuels connus. Demander uniquement les informations absentes ou sensibles avant envoi.
