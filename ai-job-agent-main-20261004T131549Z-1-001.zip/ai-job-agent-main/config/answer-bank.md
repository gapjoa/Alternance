# Banque de réponses de candidature

Dernière mise à jour : 2026-08-10

## Coordonnées

Nom complet : Swan ABEZIS

Email : swan.abezis@proton.me

Téléphone pour un formulaire français : 06 78 91 69 81

Téléphone au format international : +33 6 78 91 69 81

Localisation : Paris, France

LinkedIn : https://linkedin.com/in/swan-abezis

## Formation et alternance

Établissement : EM Normandie

Formation : Master Digital Transformation & Innovation IA

Niveau à la rentrée 2026 : Master 1, Bac+4

Diplôme préparé : Master, fin prévue en 2028

Disponibilité : fin septembre 2026 ou début octobre 2026

Durée recherchée : 24 mois

Rythme : trois semaines en entreprise et une semaine à l'école

Mobilité : Paris, La Défense et Île-de-France

## Autorisation de travail

Nationalité : française

Autorisé à travailler en France : oui

Besoin de visa ou de parrainage : non

## Rémunération

Minimum souhaité en interne : 1 400 EUR par mois

Ne jamais mentionner ce minimum dans un message ou une lettre. Si un champ obligatoire demande une prétention, répondre : Selon la grille légale et conventionnelle applicable à l'alternance.

## CV à joindre

Fichier principal : `/Users/swanabezis/Downloads/Swan_ABEZIS_CV.pdf`

Ne pas joindre : `/Users/swanabezis/Downloads/CV_Swan_ABEZIS_.docx`

## Règles de rédaction

Ne jamais inventer une expérience, un résultat, un chiffre, une compétence ou une responsabilité.

Ne jamais utiliser le caractère tiret cadratin Unicode U+2014 dans une réponse libre, un email, une lettre ou un message de candidature. Les traits d'union ordinaires restent autorisés lorsqu'ils font partie d'un mot.

Utiliser des phrases naturelles, directes et professionnelles.

Répondre automatiquement avec les informations ci-dessus après validation de l'entreprise ou de l'offre par Swan.

Suspendre l'envoi si le formulaire demande une information absente, ambiguë ou sensible.

## Filtres de poste

Cibles : Business Developer B2B, BDR, SDR, Sales, Growth Sales, Account Executive, ingénieur d'affaires et chargé de développement commercial.

Exclusions : marketing, communication, Customer Success, Customer Care et support client.

Anglais : niveau B2 déclaré. Ne pas candidater si l'annonce exige un anglais courant, fluent, bilingue ou la conduite autonome de ventes en anglais.
