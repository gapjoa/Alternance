from reportlab.lib.colors import HexColor
from reportlab.lib.enums import TA_LEFT
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib.units import mm
from reportlab.platypus import Paragraph, SimpleDocTemplate, Spacer


OUTPUT = "/Users/swanabezis/Downloads/ai-job-agent-main/output/pdf/lettre_motivation_swan_abezis_upcoop.pdf"

doc = SimpleDocTemplate(
    OUTPUT,
    pagesize=A4,
    rightMargin=24 * mm,
    leftMargin=24 * mm,
    topMargin=20 * mm,
    bottomMargin=20 * mm,
)

navy = HexColor("#17324D")
gray = HexColor("#4B5563")

name = ParagraphStyle(
    "Name",
    fontName="Helvetica-Bold",
    fontSize=17,
    leading=21,
    textColor=navy,
    spaceAfter=4,
)
contact = ParagraphStyle(
    "Contact",
    fontName="Helvetica",
    fontSize=9.5,
    leading=14,
    textColor=gray,
    spaceAfter=20,
)
meta = ParagraphStyle(
    "Meta",
    fontName="Helvetica",
    fontSize=10.5,
    leading=15,
    textColor=gray,
    spaceAfter=16,
)
subject = ParagraphStyle(
    "Subject",
    fontName="Helvetica-Bold",
    fontSize=11,
    leading=15,
    textColor=navy,
    spaceAfter=18,
)
body = ParagraphStyle(
    "Body",
    fontName="Helvetica",
    fontSize=10.5,
    leading=16,
    alignment=TA_LEFT,
    textColor=HexColor("#20252B"),
    spaceAfter=12,
)

story = [
    Paragraph("Swan ABEZIS", name),
    Paragraph("swan.abezis@proton.me &nbsp;&nbsp;|&nbsp;&nbsp; +33 6 78 91 69 81 &nbsp;&nbsp;|&nbsp;&nbsp; Paris, Île de France<br/>linkedin.com/in/swan-abezis", contact),
    Paragraph("Paris, le 10 août 2026<br/>À l'attention de l'équipe recrutement Upcoop", meta),
    Paragraph("Objet : Candidature au poste de Commercial sédentaire en alternance", subject),
    Paragraph("Madame, Monsieur,", body),
    Paragraph("Je prépare un Master Digital Transformation et Innovation IA à l'EM Normandie et je recherche une alternance de 24 mois à partir de fin septembre 2026, au rythme de trois semaines en entreprise et une semaine à l'école.", body),
    Paragraph("Mes trois années chez ShareID m'ont permis d'évoluer dans un environnement technologique B2B et de contribuer à l'identification de comptes, à la préparation de supports commerciaux et au suivi d'indicateurs avec HubSpot. Cette expérience m'a appris à travailler avec méthode, à comprendre des besoins professionnels et à utiliser les outils numériques au service du développement commercial.", body),
    Paragraph("Le poste proposé par Upcoop m'intéresse particulièrement pour sa dimension de conquête auprès des CSE et des entreprises, ainsi que pour la place donnée à l'intelligence artificielle dans la prospection et la création de valeur. Je souhaite encore progresser dans la prise de contact, la qualification et le développement d'un portefeuille, avec humilité, persévérance et sens du collectif.", body),
    Paragraph("Mobile à Gennevilliers et plus largement en Île de France, je serais heureux de pouvoir échanger avec vous sur ma motivation et sur la manière dont je pourrais contribuer à votre équipe commerciale.", body),
    Spacer(1, 8),
    Paragraph("Bien cordialement,<br/><b>Swan ABEZIS</b>", body),
]

doc.build(story)
