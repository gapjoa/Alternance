---
name: job-apply
description: Apply to a job by URL — auto-routes to the right ATS filler (LinkedIn Easy Apply / Greenhouse / Lever / Jobvite / Ashby), dry-run by default, renders an emoji-tagged result table. Proactively invoke this skill (do NOT answer conversationally) when the user pastes a LinkedIn/Greenhouse/Lever/Jobvite/Ashby job URL (with or without the word "apply"), says "apply to this", "try this one", "fill the form", "run the filler", "can you apply for me", "submit this application", drops a job posting into chat, or invokes /job-apply.
argument-hint: "<job URL>  (add --submit to actually submit; default is dry-run)"
allowed-tools:
  - Bash
  - Read
  - Write
---

# Job Apply

Fills out a job application form on the 5 ATS platforms this repo supports. Default is **dry-run** — the form is filled but not submitted.

## Repo location

Resolve the repo root in this order:

1. `$AI_JOB_AGENT_ROOT` env var
2. `~/.claude/skills/ai-job-agent/` (gstack-style install — recommended)
3. `~/.claude/skills/ai-job-agent/REPO_PATH` file (legacy, when repo is elsewhere)
4. `~/ai-job-agent/` (legacy manual-clone fallback)

Check for `package.json` in the candidate path to confirm it's really the repo. Fail with a clear message if none exist.

## Workflow

### 1. Parse `$ARGUMENTS`

Expect `<URL> [--submit]`. If no URL, ask the user for one.

### 2. Route by URL host

| Host pattern | Script |
|-------------|--------|
| `linkedin.com/jobs/view/*` | `scripts/linkedin-easy-apply.js` |
| `boards.greenhouse.io/*` or `job-boards.greenhouse.io/*` | `scripts/greenhouse-apply.js` |
| `jobs.lever.co/*` | `scripts/lever-apply.js` |
| `jobs.jobvite.com/*` or `*.jobs.jobvite.com/*` | `scripts/jobvite-apply.js` |
| `jobs.ashbyhq.com/*` or `ashbyhq.com/*` | `scripts/ashby-apply.js` |

If the URL doesn't match, print the table of supported hosts and stop.

### 3. Check config

For LinkedIn: `config/linkedin-config.json` must exist.
For the other four: the user provides a second argument pointing to their form config JSON (per-job, by convention).

If missing, tell the user to run `bash wizard.sh` (for LinkedIn) or point to their filled form config.

### 4. Run the filler

Dry-run by default:

```bash
cd "$AI_JOB_AGENT_ROOT"
node scripts/linkedin-easy-apply.js "$URL" config/linkedin-config.json
```

With `--submit`, set `autoSubmit: true` in the config temporarily (or instruct the user to — do not silently flip it without confirming). Prefer: ask the user to set it themselves if they haven't, to preserve the truthfulness guardrail baked into `CLAUDE.md`.

Environment variables to surface:
- `HEADLESS=0` if the user wants to watch the browser
- `KEEP_OPEN_ON_BLOCK=1` if they want to inspect a stalled form
- `CDP_URL` if they want to connect to an already-open Chrome

### 5. Parse the script's JSON output

All five fillers emit structured JSON on stdout. Exit codes:

| Code | Meaning |
|------|---------|
| 0 | Success (submitted, or ready in dry-run) |
| 1 | Crash / unexpected error |
| 2 | Blocked on unknown required field |
| 3 | CAPTCHA or submission timeout |
| 4 | Step limit exceeded (LinkedIn only) |

### 6. Render result table

Show the user a compact markdown table:

| Field | Value |
|-------|-------|
| Company | … |
| Role | … |
| Platform | LinkedIn / Greenhouse / Lever / Jobvite / Ashby |
| Result | ✅ submitted / ⏳ dry-run filled / 🚫 blocked / 🤖 captcha / 💥 crash |
| Exit code | 0 / 1 / 2 / 3 / 4 |
| URL | `<url>` |

Pick the single emoji that matches the exit code, don't list all four — one of ✅ ⏳ 🚫 🤖 💥 in the `Result` cell.

Then ask: "Log this to the tracker? (y/n)" — if yes, append a row to `application-tracker.csv` with the columns in `templates/tracker.template.csv`, then optionally kick off `/job-track` to sync.

## Rules (from root CLAUDE.md)

- **Truthfulness first** — CAPTCHA stalls are logged as `blocked`, never `submitted`.
- **Skip hard citizen/green-card gated roles** unless the form provides a truthful path.
- **Resume routing** — software/AI roles use the software resume; EE/embedded roles use the EE resume. See `config/candidate-profile.md` for the mapping.
