# Swan ABEZIS

Business Development & Growth | Fintech · Conformité · Identité numérique

Paris · +33 6 78 91 69 81 · swan.abezis@proton.me · https://linkedin.com/in/swan-abezis

## Profil

Recherche une alternance Business Development / Growth en fintech, paiements ou banque, dès septembre 2026, dans le cadre du Master Digital Transformation & Innovation IA à l'EM Normandie. Trois ans d'expérience chez ShareID, éditeur de solutions de vérification d'identité pour le secteur financier, avec une évolution interne de l'annotation de données IA au business development. Maîtrise des enjeux de conformité du secteur et conception de systèmes d'automatisation marketing générateurs de pipeline commercial.

## Expériences

### Business Development & IA Marketing — ShareID | 2025-2026

- Conception et déploiement d'un pipeline d'audit SEO automatisé en sept phases avec Make.com et l'API Claude, exécuté chaque nuit avec reporting quotidien et sans intervention manuelle.
- Construction d'un système automatisé de production de contenus LinkedIn destiné aux décideurs conformité et risque des établissements financiers, avec deux à trois publications par semaine en français et en anglais.
- Représentation de ShareID lors de salons professionnels, notamment le FIC et VivaTech 2026 sur le stand Orange, avec génération de leads qualifiés.
- Production de supports de réponse à des appels d'offres bancaires et fintechs en collaboration directe avec la CEO.
- Rédaction et vérification de contenus réglementaires sur KYC/AML, eIDAS 2.0, MiCA/CASP, DORA, DSP2 et EUDI Wallet : newsletters, articles et livre blanc de dix chapitres.
- Suivi des KPI d'acquisition et optimisation des parcours de vérification d'identité côté conversion.

### Opérateur puis annotateur de données IA — ShareID | 2023-2025

- Préparation et annotation de jeux de données d'entraînement pour des modèles IA de détection biométrique.
- Traitement en production de demandes de vérification d'identité de clients du secteur financier.
- Évolution interne vers le marketing puis le business development, soit trois fonctions en trois ans dans la même entreprise.

### Chef de projet junior, secteur du luxe — Inovad | 2024-2025

- Gestion de huit comptes Instagram de marques du luxe et exploration de plus de dix marchés internationaux.
- Réalisation d'une douzaine d'audits web avec recommandations d'amélioration livrées aux clients.

### Stage découverte, cybersécurité — Open Sezam | Juillet 2022

- Première immersion dans l'authentification sans mot de passe et la gestion des accès, à l'origine d'une orientation vers l'identité numérique et la sécurisation des services financiers.

## Projets

- Conseil startups : accompagnement de deux startups dans leur préparation à la levée de fonds — pitch decks investisseurs FR/EN, benchmark de levées de Series A et mapping d'investisseurs.
- MindCare : cadrage produit, tests utilisateurs, business plan et soutenance investisseur pour une PWA de bien-être mental réalisée en équipe à Ynov.

## Formation

- Master Digital Transformation & Innovation IA — EM Normandie | 2026-2028
- Bachelor Tech & Business, certification Chef de Projets Digitaux — Ynov Paris | 2023-2026
- Baccalauréat scientifique — Lycée Évariste Galois | 2023

## Compétences

- Réglementaire : KYC/AML, eIDAS 2.0, MiCA/CASP, DORA, DSP2, EUDI Wallet.
- Outils et automatisation : Make.com, API Claude, HubSpot, Apollo, Figma, Webflow, Pack Office.
- Business : génération de leads B2B, appels d'offres, growth marketing, KPI et reporting.
- Langues : français natif, anglais B2, chinois A1.

## Centres d'intérêt

Marchés crypto et régulation des actifs numériques · Échecs et poker · Boxe anglaise · Voyages dans plus de vingt pays · Assesseur bénévole
